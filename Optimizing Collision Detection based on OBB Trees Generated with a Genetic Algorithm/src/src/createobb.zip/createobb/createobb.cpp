#include <stdio.h>

#include "..\..\include\defs.h"
#include "..\..\include\off.h"
#include "..\..\include\obb.h"
#include "..\..\include\obbnode.h"
#include "..\..\include\obbtree.h"


// Settings: ..\..\data\finalprotesis.off protesis.obb
#include <string>
using namespace std;
int main(int args, char **argv)
{
 /*
	argv[1] = "FinalTibiaSinTapa.off";
 argv[2] = "some.obb";
 */
	//argv[1] = "teapot.OFF";
	//argv[2] = "teapot.obb";
	/*
	argv[1] = "sphere.off";
	if(USE_GENETIC)
		argv[2] = "Genesphere.obb";
	else
		argv[2] = "MCsphere.obb";
		*/
 /*
 if (args!=3)
 {
  printf("uso: createabb infile.off outfile.aabb\n");
  return 0;
 }
 */
 OFF off;
 if (off.load(argv[1]))
 {
  OBBTree tree(&off);
  //OBBTree tree;

  tree.write(argv[2]);

  //tree.read("tibia.obb");

  std::string filename;
  filename.append(argv[2]);
  int c = tree.countLeaves();
  int t = tree.getTotal();
  int m = tree.getWorst();
  int a = tree.getAverage();
  printf("Leaves: %d\nTotal triangles: %d\nWorst node: %d\nAverage: %d\n", c, t, m, a);
  printf("Volumen = %f\n",tree.GetVolumeValue());
 }
 else
 {
  printf("file not found: %s\n", argv[1]);
  return 0;
 }

 return 1;
}
